create definer = scrum_library@localhost trigger update_book_copy_status_after_insert
    after insert
    on borrow_record
    for each row
BEGIN
    UPDATE scrum_library.book_copy AS bc
    SET
        bc.status = 'NOT_AVAILABLE'
    WHERE bc.book_copy_id =  NEW.book_copy_book_copy_id;
END;

