create definer = scrum_library@localhost trigger update_book_availableCopies_after_insert
    after insert
    on book_copy
    for each row
BEGIN
    UPDATE scrum_library.book
    SET total_copies = total_copies + 1
    WHERE book_id = NEW.book_book_id;
END;

