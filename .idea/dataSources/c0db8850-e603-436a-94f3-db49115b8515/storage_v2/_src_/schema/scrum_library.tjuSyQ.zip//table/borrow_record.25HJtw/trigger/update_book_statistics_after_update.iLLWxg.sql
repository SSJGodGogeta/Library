create definer = scrum_library@localhost trigger update_book_statistics_after_update
    after update
    on borrow_record
    for each row
BEGIN
    UPDATE scrum_library.book AS b
    SET
        
        b.available_copies = b.available_copies + IF(NEW.status = 'RETURNED' AND OLD.status = 'BORROWED' OR OLD.status = 'RESERVED', 1, 0),

        
        b.sum_rating = b.sum_rating + IF(NEW.rating IS NOT NULL AND OLD.rating IS NULL, NEW.rating, 0),
        b.count_rating = b.count_rating + IF(NEW.rating IS NOT NULL AND OLD.rating IS NULL, 1, 0),
        b.average_rating = IF(b.count_rating > 0, b.sum_rating / b.count_rating, NULL)
    WHERE b.book_id = (
        SELECT bc.book_book_id
        FROM scrum_library.book_copy AS bc
        WHERE bc.book_copy_id = NEW.book_copy_book_copy_id
    );
END;

