create definer = scrum_library@localhost trigger update_book_copy_after_borrow_delete
    after delete
    on borrow_record
    for each row
BEGIN
    UPDATE scrum_library.book_copy AS bc
    SET bc.status = IF(OLD.status = 'BORROWED', 'NOT_BORROWED', bc.status)
    WHERE bc.book_copy_id = OLD.book_copy_book_copy_id;
END;

