create definer = scrum_library@localhost trigger update_book_after_borrow_delete
    after delete
    on borrow_record
    for each row
BEGIN
    UPDATE scrum_library.book AS b
    SET
        
        b.available_copies = b.available_copies + IF(OLD.status = 'BORROWED', 1, 0)
    WHERE b.book_id = (
        SELECT bc.book_book_id
        FROM scrum_library.book_copy AS bc
        WHERE bc.book_copy_id = OLD.book_copy_book_copy_id
    );
END;

